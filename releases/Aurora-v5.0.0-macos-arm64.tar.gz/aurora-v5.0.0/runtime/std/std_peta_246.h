/*
 * Aurora 标准库 - 标准库拍它模块 246
 */

#ifndef AURORA_STD_PETA_246_H
#define AURORA_STD_PETA_246_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_peta_246_act_000(int x);
void* std_peta_246_build_000(void* p);
int std_peta_246_act_001(int x);
void* std_peta_246_build_001(void* p);
int std_peta_246_act_002(int x);
void* std_peta_246_build_002(void* p);
int std_peta_246_act_003(int x);
void* std_peta_246_build_003(void* p);

#endif /* AURORA_STD_PETA_246_H */