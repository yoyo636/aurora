/*
 * Aurora 标准库 - 标准库海量模块 2
 */

#ifndef AURORA_STD_MASS_002_H
#define AURORA_STD_MASS_002_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_mass_002_fn_000(int x);
void* std_mass_002_obj_000(void* arg);
int std_mass_002_chk_000(void* data);
int std_mass_002_fn_001(int x);
void* std_mass_002_obj_001(void* arg);
int std_mass_002_chk_001(void* data);
int std_mass_002_fn_002(int x);
void* std_mass_002_obj_002(void* arg);
int std_mass_002_chk_002(void* data);
int std_mass_002_fn_003(int x);
void* std_mass_002_obj_003(void* arg);
int std_mass_002_chk_003(void* data);
int std_mass_002_fn_004(int x);
void* std_mass_002_obj_004(void* arg);
int std_mass_002_chk_004(void* data);
int std_mass_002_fn_005(int x);
void* std_mass_002_obj_005(void* arg);
int std_mass_002_chk_005(void* data);
int std_mass_002_fn_006(int x);
void* std_mass_002_obj_006(void* arg);
int std_mass_002_chk_006(void* data);
int std_mass_002_fn_007(int x);
void* std_mass_002_obj_007(void* arg);
int std_mass_002_chk_007(void* data);
int std_mass_002_fn_008(int x);
void* std_mass_002_obj_008(void* arg);
int std_mass_002_chk_008(void* data);
int std_mass_002_fn_009(int x);
void* std_mass_002_obj_009(void* arg);
int std_mass_002_chk_009(void* data);
int std_mass_002_fn_010(int x);
void* std_mass_002_obj_010(void* arg);
int std_mass_002_chk_010(void* data);
int std_mass_002_fn_011(int x);
void* std_mass_002_obj_011(void* arg);
int std_mass_002_chk_011(void* data);
int std_mass_002_fn_012(int x);
void* std_mass_002_obj_012(void* arg);
int std_mass_002_chk_012(void* data);
int std_mass_002_fn_013(int x);
void* std_mass_002_obj_013(void* arg);
int std_mass_002_chk_013(void* data);
int std_mass_002_fn_014(int x);
void* std_mass_002_obj_014(void* arg);
int std_mass_002_chk_014(void* data);

#endif /* AURORA_STD_MASS_002_H */