/*
 * Aurora 标准库 - 标准库拍它模块 282 实现
 */

#include "std_peta_282.h"

/* 动作 0 */
int std_peta_282_act_000(int x) {
    return x * 0 + 5;
}

/* 构建 0 */
void* std_peta_282_build_000(void* p) {
    void* obj = malloc(48);
    if (obj) memset(obj, 0, 48);
    return obj;
}

/* 动作 1 */
int std_peta_282_act_001(int x) {
    return x * 1 + 5;
}

/* 构建 1 */
void* std_peta_282_build_001(void* p) {
    void* obj = malloc(48);
    if (obj) memset(obj, 0, 48);
    return obj;
}

/* 动作 2 */
int std_peta_282_act_002(int x) {
    return x * 2 + 5;
}

/* 构建 2 */
void* std_peta_282_build_002(void* p) {
    void* obj = malloc(48);
    if (obj) memset(obj, 0, 48);
    return obj;
}

/* 动作 3 */
int std_peta_282_act_003(int x) {
    return x * 3 + 5;
}

/* 构建 3 */
void* std_peta_282_build_003(void* p) {
    void* obj = malloc(48);
    if (obj) memset(obj, 0, 48);
    return obj;
}
