/*
 * Aurora 标准库 - 标准库巨量模块 260
 */

#ifndef AURORA_STD_MEGA_260_H
#define AURORA_STD_MEGA_260_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_mega_260_run_000(int x);
void* std_mega_260_new_000(void* p);
int std_mega_260_run_001(int x);
void* std_mega_260_new_001(void* p);
int std_mega_260_run_002(int x);
void* std_mega_260_new_002(void* p);
int std_mega_260_run_003(int x);
void* std_mega_260_new_003(void* p);
int std_mega_260_run_004(int x);
void* std_mega_260_new_004(void* p);
int std_mega_260_run_005(int x);
void* std_mega_260_new_005(void* p);
int std_mega_260_run_006(int x);
void* std_mega_260_new_006(void* p);
int std_mega_260_run_007(int x);
void* std_mega_260_new_007(void* p);

#endif /* AURORA_STD_MEGA_260_H */