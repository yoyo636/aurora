/*
 * Aurora 标准库 - 标准库容那模块 1070
 */

#ifndef AURORA_STD_RONNA_1070_H
#define AURORA_STD_RONNA_1070_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_ronna_1070_do_000(int x);
void* std_ronna_1070_new_000(void* p);

#endif /* AURORA_STD_RONNA_1070_H */