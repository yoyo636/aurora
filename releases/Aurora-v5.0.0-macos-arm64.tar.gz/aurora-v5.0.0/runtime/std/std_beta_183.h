/*
 * Aurora 标准库 - 标准库贝塔模块 183
 */

#ifndef AURORA_STD_BETA_183_H
#define AURORA_STD_BETA_183_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_beta_183_run_000(int x);
void* std_beta_183_make_000(void* p);

#endif /* AURORA_STD_BETA_183_H */