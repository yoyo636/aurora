/*
 * Aurora 标准库 - 标准库泽它模块 1055
 */

#ifndef AURORA_STD_ZETTA_1055_H
#define AURORA_STD_ZETTA_1055_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_zetta_1055_run_000(int x);
void* std_zetta_1055_make_000(void* p);
int std_zetta_1055_run_001(int x);
void* std_zetta_1055_make_001(void* p);

#endif /* AURORA_STD_ZETTA_1055_H */