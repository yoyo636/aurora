/*
 * Aurora 标准库 - 标准库艾可萨模块 985
 */

#ifndef AURORA_STD_EXA_985_H
#define AURORA_STD_EXA_985_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_exa_985_op_000(int x);
void* std_exa_985_gen_000(void* p);
int std_exa_985_op_001(int x);
void* std_exa_985_gen_001(void* p);
int std_exa_985_op_002(int x);
void* std_exa_985_gen_002(void* p);

#endif /* AURORA_STD_EXA_985_H */