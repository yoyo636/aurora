/*
 * Aurora 标准库 - 标准库终极模块 294
 */

#ifndef AURORA_STD_ULTIMA_294_H
#define AURORA_STD_ULTIMA_294_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_ultima_294_do_000(int x);
void* std_ultima_294_new_000(void* p);

#endif /* AURORA_STD_ULTIMA_294_H */