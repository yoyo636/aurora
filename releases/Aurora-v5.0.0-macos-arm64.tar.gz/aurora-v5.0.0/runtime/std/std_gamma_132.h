/*
 * Aurora 标准库 - 标准库伽马模块 132
 */

#ifndef AURORA_STD_GAMMA_132_H
#define AURORA_STD_GAMMA_132_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_gamma_132_do_000(int x);
void* std_gamma_132_new_000(void* p);

#endif /* AURORA_STD_GAMMA_132_H */