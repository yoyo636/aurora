/*
 * Aurora 标准库 - 标准库伽马模块 449
 */

#ifndef AURORA_STD_GAMMA_449_H
#define AURORA_STD_GAMMA_449_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_gamma_449_do_000(int x);
void* std_gamma_449_new_000(void* p);

#endif /* AURORA_STD_GAMMA_449_H */