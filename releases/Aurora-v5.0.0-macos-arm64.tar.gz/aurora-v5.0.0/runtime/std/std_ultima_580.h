/*
 * Aurora 标准库 - 标准库终极模块 580
 */

#ifndef AURORA_STD_ULTIMA_580_H
#define AURORA_STD_ULTIMA_580_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_ultima_580_do_000(int x);
void* std_ultima_580_new_000(void* p);

#endif /* AURORA_STD_ULTIMA_580_H */