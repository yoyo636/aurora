/*
 * Aurora 标准库 - 标准库伽马模块 1186
 */

#ifndef AURORA_STD_GAMMA_1186_H
#define AURORA_STD_GAMMA_1186_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int std_gamma_1186_do_000(int x);
void* std_gamma_1186_new_000(void* p);

#endif /* AURORA_STD_GAMMA_1186_H */