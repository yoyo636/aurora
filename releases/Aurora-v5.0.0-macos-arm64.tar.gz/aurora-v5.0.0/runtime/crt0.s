// crt0.s — Aurora 启动代码 (macOS arm64)
// 用标准的 _main 入口

    .text
    .global _main
    .align 2

_main:
    stp x29, x30, [sp, #-16]!
    mov x29, sp

    bl __aurora_entry

    ldp x29, x30, [sp], #16
    ret
